package com.informatica.mdm.hubuserexit.postload;

import org.apache.log4j.Logger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.log4j.Logger;

public class UpdatePrtyFkBUddp 
{
	private static Logger log = Logger.getLogger(GeneratePrchsFrmId.class);
	
	public void UpdatePrtyFkBUddpNew(String rowIdobject,String prtyRowIdobject,Statement stmt) {
		
		log.info("We are in UpdatePrtyFkBUddpNew");
		
		log.info("RowidObject --- " +rowIdobject);
		log.info("PartyRowidObject --- " +prtyRowIdobject);
		
		try {
			if(rowIdobject != null && prtyRowIdobject != null) {
				log.info("UPDATE SUPPLIER_HUB.C_XO_SUPP_ACC_BU_DDP SET X_PMNT_PRTY_FK='"+prtyRowIdobject
						+"' WHERE ROWID_OBJECT =" + rowIdobject + "");
				stmt.executeUpdate("UPDATE SUPPLIER_HUB.C_XO_SUPP_ACC_BU_DDP SET X_PMNT_PRTY_FK='"+prtyRowIdobject
						+"' WHERE ROWID_OBJECT =" + rowIdobject + "");
				log.info("UPDATE SUPPLIER_HUB.C_XO_SUPP_ACC_BU_DDP_XREF SET S_X_PMNT_PRTY_FK='"+prtyRowIdobject
						+"',X_PMNT_PRTY_FK=(SELECT ROWID_XREF FROM SUPPLIER_HUB.C_BO_PRTY_XREF cbpx WHERE ROWID_OBJECT ='"
						+rowIdobject+"'ORDER BY LAST_UPDATE_DATE ASC FETCH FIRST 1 ROWS ONLY ) WHERE ROWID_OBJECT =" + rowIdobject + "");
				stmt.executeUpdate("UPDATE SUPPLIER_HUB.C_XO_SUPP_ACC_BU_DDP_XREF SET S_X_PMNT_PRTY_FK='"+prtyRowIdobject
						+"',X_PMNT_PRTY_FK=(SELECT ROWID_XREF FROM SUPPLIER_HUB.C_BO_PRTY_XREF cbpx WHERE ROWID_OBJECT ='"
						+rowIdobject+"'ORDER BY LAST_UPDATE_DATE ASC FETCH FIRST 1 ROWS ONLY ) WHERE ROWID_OBJECT =" + rowIdobject + "");
			}
			else {
				log.info("NULL VALUES FOUND.");
			}
			
		} catch (SQLException e) {
			log.info("Exception in UpdatePrtyFkBUddpNew. ---- " +e);
			e.printStackTrace();
		}
		
		
	}
}
